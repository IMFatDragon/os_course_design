package caozuoxitongkeshe;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;


public class DiskOperation extends JFrame implements ActionListener
{
	int k;
ImageIcon img;
JSplitPane vsplitPane;
JSplitPane hsplitPane;
LogPane log;
JButton sureButton,button1;
BackgroundPanel centerPane;
BackgroundPanel southPane;
BackgroundPanel pane;
static JPanel controlPane;
static CardLayout card;
Font font=new Font("΢���ź�",Font.PLAIN,16);
JLabel label,label1;
JTextField textField,textField1;
ArithPane arithPane;
static  int cidao[];
public DiskOperation( )
{

 try { 
       UIManager
         .setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
      } catch (Exception e) {
       e.printStackTrace();
      } 

try {
    init();
} catch (Exception e) {
    log.addLog(e.toString());
}
}


private void setBorder(TitledBorder titledBorder) {

}


public void init() throws Exception{
arithPane=new ArithPane();  
card=new CardLayout();
controlPane=new JPanel();
controlPane.setLayout(card);
controlPane.add("����", arithPane);
cidao=new int[1000];

textField=new JTextField();
textField.setFont(font);
textField.setBounds(150, 150, 300, 30);

textField1=new JTextField();
textField1.setFont(font);
textField1.setBounds(150,70, 300, 30);

label1=new JLabel("������ŵ����и���");
label1.setFont(font);
label1.setBounds(220, 30, 350, 30);

label=new JLabel("�������Ҫ�������Ĵŵ�����");
label.setFont(font);
label.setBounds(190, 110, 350, 30);


log=LogPane.getLog();
log.addLog("��ӭ����ģ����̵��Ƚ���!");

pane=new BackgroundPanel();
pane.setLayout(new BorderLayout());

controlPane.add("���һ", pane);
card.show(controlPane,"���һ");

centerPane=new BackgroundPanel();
centerPane.setLayout(null);

centerPane.add(label1);
centerPane.add(textField1);
centerPane.add(label);
centerPane.add(textField);


button1 = new JButton("���������");
button1 .setFont(font);
button1.addActionListener( new ActionListener() { 
	public void actionPerformed(ActionEvent e) 
	{ 
		k=Integer.valueOf(textField1.getText());
		int a[]=new int[k];
	    for(int i=0;i<k;i++){
		a[i]=(int)(Math.random()*200)+1;
		}
	  String s = Arrays.toString(a);
	  String s1 =s.substring(1, s.length()-1).replaceAll(",","");
	  textField.setText( s1 );
	 // System.out.println(s1);
	
	}
});



sureButton=new JButton("ѡ���㷨");
sureButton.setFont(font);
sureButton.addActionListener(this);

southPane=new BackgroundPanel();
southPane.setLayout(new FlowLayout());
southPane.add(button1);
southPane.add(sureButton);


pane.add(southPane,BorderLayout.SOUTH);
pane.add(centerPane);
ImageIcon loginIcon = CreatIcon.add("login.jpg");
loginIcon.setImage(loginIcon.getImage().getScaledInstance(650,550, Image.SCALE_DEFAULT));
pane.setImage(loginIcon.getImage());

vsplitPane=new JSplitPane(JSplitPane.VERTICAL_SPLIT);
vsplitPane.setTopComponent(new JScrollPane(controlPane));
vsplitPane.setBottomComponent( log);
vsplitPane.setDividerLocation(320);
vsplitPane.setEnabled(false);

int screen_width = Toolkit.getDefaultToolkit().getScreenSize().width;  
int screen_height = Toolkit.getDefaultToolkit().getScreenSize().height;  

add(vsplitPane);

setSize(630,530);
setLocation((screen_width - this.getWidth()) / 2,  
        (screen_height - this.getHeight()) / 2);  
setBackground(Color.LIGHT_GRAY);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);
setBorder(new TitledBorder("ģ����̵���"));
setResizable(false);
setTitle("ģ����̵����㷨");  
}

public void actionPerformed(ActionEvent e){

  if(e.getSource()==sureButton){

      String str=textField.getText();
    //  System.out.println(str);
      if(str.trim().equals(" ")){ 
          JOptionPane.showMessageDialog(this, "�ŵ������в���Ϊ��!", "��ʾ", 
                  JOptionPane.WARNING_MESSAGE);
      }
      else{
          try{
              String[] buffer=str.split(" ");
             // System.out.println(buffer);
              if(buffer.length>0){
                  for(int i=0;i<buffer.length;i++){
                      cidao[i]=Integer.parseInt(buffer[i]);

                  }
                  log.addLog("������Ĵŵ�����Ϊ:"+str);
                  card.show(controlPane, "����");
              }
              else{
                  JOptionPane.showMessageDialog(this, "����ĸ�ʽ����", "��ʾ", 
                          JOptionPane.WARNING_MESSAGE);
              }

          }
          catch(Exception e1){
              e1.printStackTrace();
              JOptionPane.showMessageDialog(this, "����ĸ�ʽ����", "��ʾ", 
                      JOptionPane.WARNING_MESSAGE);
          }
      }
  }
 }

public static  int[] getCidao(){
    return cidao;
}


public  static void showCard(){
    card.show(controlPane,"���һ");
}
public static void main(String[]args){

    new DiskOperation();
}

}