package caozuoxitongkeshe;

import javax.swing.ImageIcon;

public class CreatIcon {
	static String path = System.getProperty("user.dir") + "\\res\\";

	public static ImageIcon add(String ImageName) {
		ImageIcon icon = new ImageIcon(path + ImageName);
		return icon;
	}
}