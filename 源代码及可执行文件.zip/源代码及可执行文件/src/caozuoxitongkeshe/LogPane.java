package caozuoxitongkeshe;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Date;
public class LogPane extends JTabbedPane implements ActionListener{
private JScrollPane scroll;
private JTextArea textArea;
static final LogPane log=new LogPane();
    public LogPane() {
        // TODO �Զ����ɵĹ��캯�����
        try {  
               UIManager
                 .setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
              } catch (Exception e) {
               e.printStackTrace();
              }

        textArea=new JTextArea();
        textArea.setLineWrap(true);
        textArea.setFont(new Font("TimesRoman",Font.PLAIN,18));
        scroll=new JScrollPane(textArea);
        add(scroll,BorderLayout.CENTER);
        this.setTitleAt(0, "Log");
        this.setFont(new Font("΢���ź�",Font.BOLD,16));
        this.setEnabled(false);
        textArea.setEditable(false);
    }

    public void actionPerformed(ActionEvent arg0) {

    }

    public void addLog(String log){
        textArea.append(log+"\n");
    }

    public static LogPane getLog(){

        return log;
    }

    public void addLog(String str,Color color){
        Date date=new Date();
        textArea.setForeground(color);
        textArea.append(str+"\t"+date+"\n");
    }
}
